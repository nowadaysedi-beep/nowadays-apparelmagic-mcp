# NOWADAYS ApparelMagic MCP OAuth Proxy

This service lets ChatGPT connect to ApparelMagic's Streamable HTTP MCP endpoint.

It exposes an OAuth-protected MCP endpoint to ChatGPT and forwards authenticated requests to:

`https://api.apparelmagic.com/mcp`

Each upstream request receives:

`X-API-Key: <APPARELMAGIC_API_KEY>`

## Render settings

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/health`

## Required environment variables

- `APPARELMAGIC_API_KEY`: a new ApparelMagic read-only MCP token
- `OAUTH_ADMIN_PASSWORD`: password shown during the ChatGPT authorization flow
- `JWT_SECRET`: long random secret; Render can generate it

Optional:

- `PUBLIC_BASE_URL`: only needed if Render's automatic `RENDER_EXTERNAL_URL` is unavailable
- `UPSTREAM_MCP_URL`: defaults to `https://api.apparelmagic.com/mcp`
- `OAUTH_SCOPE`: defaults to `mcp:tools:read`

## ChatGPT endpoint

After deployment, use:

`https://YOUR-RENDER-SERVICE.onrender.com/mcp`

Do not commit the ApparelMagic API token to GitHub.
